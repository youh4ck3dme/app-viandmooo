Public Images Skeleton
=======================

Toto sú dočasné zástupné obrázky (placeholders) so správnymi názvami.
Stačí ich nahradiť vašimi reálnymi fotkami pri zachovaní rovnakých mien súborov.

Hero (1920x1080):
- hero-background.jpg
- stahovanie-bytov-hero.jpg
- stahovanie-klavirov-hero.jpg
- vypratavanie-hero.jpg
- about-hero.jpg
- blog-hero.jpg

Other (1600x1067):
- about-packing.jpg
- team-member-1.jpg
- team-member-2.jpg
- blog-post-1.jpg
- blog-post-2.jpg
- blog-post-3.jpg
